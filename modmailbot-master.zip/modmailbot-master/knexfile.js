const knexConfig = require("./src/knexConfig");
module.exports = knexConfig;
